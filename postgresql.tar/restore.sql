--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DataBasesProject";
--
-- Name: DataBasesProject; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "DataBasesProject" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1256';


ALTER DATABASE "DataBasesProject" OWNER TO postgres;

\connect "DataBasesProject"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calculate_ticket_price(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_ticket_price(time_of_travel integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    ticket_price INT;
BEGIN
        ticket_price := 20 * time_of_travel;

    -- Return the calculated ticket price
    RETURN ticket_price;
END;
$$;


ALTER FUNCTION public.calculate_ticket_price(time_of_travel integer) OWNER TO postgres;

--
-- Name: calculate_ticket_price_vip(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_ticket_price_vip(time_of_travel integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    ticket_price INT;
BEGIN
        ticket_price := 40 * time_of_travel;

    -- Return the calculated ticket price
    RETURN ticket_price;
END;
$$;


ALTER FUNCTION public.calculate_ticket_price_vip(time_of_travel integer) OWNER TO postgres;

--
-- Name: delete_all_person(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_all_person() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM person;
    RETURN;

END;
$$;


ALTER FUNCTION public.delete_all_person() OWNER TO postgres;

--
-- Name: make_booking(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.make_booking() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO booking("ticketId","gateId","planId") 
    VALUES (NEW."ticketId",NEW."gateId",NEW."planId");
RETURN new;
END;
$$;


ALTER FUNCTION public.make_booking() OWNER TO postgres;

--
-- Name: manager_update_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.manager_update_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE NOTICE 'Updated manager record: managerId=%',
        OLD."managerId";
        INSERT INTO managers_update("lastManagerId","lastManagerName","newManagerId","newManagerName")
        VALUES (OLD."managerId",
        (SELECT "name" FROM person WHERE "personId" = OLD."managerId")
        ,NEW."managerId",
        (SELECT "name" FROM person WHERE "personId" = NEW."managerId"));
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.manager_update_trigger() OWNER TO postgres;

--
-- Name: person_update_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.person_update_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE NOTICE 'Updated person record: personId=%, old_name=%, new_name=%',
        OLD."personId", OLD."name", NEW."name";
        INSERT INTO person_name_update("personId","oldName","newName") 
        VALUES(OLD."personId", OLD."name", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.person_update_trigger() OWNER TO postgres;

--
-- Name: personadd(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.personadd(personno integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN   
    IF personNo > 0 THEN
        FOR i IN 1 .. personNo LOOP
            INSERT INTO "person" ("name","surname", "Tel no","passenger","employee") 
            VALUES(
                substring('ABCDEFGHIiJKLMNOPRSTUVYZ' from ceil(random()*10)::smallint for ceil(random()*20)::SMALLINT), 
                substring('ABCDEFGHIiJKLMNOPRSTUVYZ' from ceil(random()*10)::smallint for ceil(random()*20)::SMALLINT),
                floor(random() * 100000)::bigint,
                RANDOM() < 0.5,
                RANDOM() > 0.5
                 );
        END LOOP;
    END IF; 
END;
$$;


ALTER FUNCTION public.personadd(personno integer) OWNER TO postgres;

--
-- Name: ticket_delete_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ticket_delete_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE NOTICE 'Deleted ticket record: ticketId=%, baggage=%',
        OLD."ticketId", OLD."baggage";
    INSERT INTO ticket_canceletion ("ticketId", "passenger", "passengerId")
    VALUES (OLD."ticketId", 
            (SELECT "name" FROM person WHERE "personId" = OLD."passengerId" LIMIT 1), 
            OLD."passengerId");

    RETURN OLD;
END;
$$;


ALTER FUNCTION public.ticket_delete_trigger() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adress (
    "adressId" integer NOT NULL,
    "countryId" integer,
    "cityId" integer
);


ALTER TABLE public.adress OWNER TO postgres;

--
-- Name: adress_adressId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."adress_adressId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."adress_adressId_seq" OWNER TO postgres;

--
-- Name: adress_adressId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."adress_adressId_seq" OWNED BY public.adress."adressId";


--
-- Name: airplane; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.airplane (
    "airplaneId" integer NOT NULL,
    "pilotId" integer,
    passengers integer[],
    gate integer
);


ALTER TABLE public.airplane OWNER TO postgres;

--
-- Name: airplane_airplaneId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."airplane_airplaneId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."airplane_airplaneId_seq" OWNER TO postgres;

--
-- Name: airplane_airplaneId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."airplane_airplaneId_seq" OWNED BY public.airplane."airplaneId";


--
-- Name: baggage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.baggage (
    "baggageId" integer NOT NULL,
    "passengerId" integer,
    weight double precision
);


ALTER TABLE public.baggage OWNER TO postgres;

--
-- Name: booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.booking (
    "bookingId" integer NOT NULL,
    "planId" integer,
    "gateId" integer,
    "ticketId" integer
);


ALTER TABLE public.booking OWNER TO postgres;

--
-- Name: booking_bookingId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."booking_bookingId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."booking_bookingId_seq" OWNER TO postgres;

--
-- Name: booking_bookingId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."booking_bookingId_seq" OWNED BY public.booking."bookingId";


--
-- Name: city; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city (
    "cityId" integer NOT NULL,
    "cityName" character varying(15)
);


ALTER TABLE public.city OWNER TO postgres;

--
-- Name: country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.country (
    "countryId" integer NOT NULL,
    "countryName" character varying(15)
);


ALTER TABLE public.country OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    "employeeId" integer NOT NULL,
    "startedData" date,
    salary money,
    kind character(1)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: gates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gates (
    "gatesId" integer NOT NULL,
    "gateName" character varying(15)
);


ALTER TABLE public.gates OWNER TO postgres;

--
-- Name: manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manager (
    "managerId" integer NOT NULL
);


ALTER TABLE public.manager OWNER TO postgres;

--
-- Name: managers_update; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.managers_update (
    "manUpdate" integer NOT NULL,
    "lastManagerId" integer,
    "lastManagerName" character varying(15),
    "newManagerId" integer,
    "newManagerName" character varying(15)
);


ALTER TABLE public.managers_update OWNER TO postgres;

--
-- Name: managers_update_manUpdate_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."managers_update_manUpdate_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."managers_update_manUpdate_seq" OWNER TO postgres;

--
-- Name: managers_update_manUpdate_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."managers_update_manUpdate_seq" OWNED BY public.managers_update."manUpdate";


--
-- Name: normal_plan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.normal_plan (
    "normalPlanId" integer NOT NULL,
    balance money,
    "maxBaggageNo" smallint DEFAULT 2,
    "maxWeight" double precision DEFAULT 24,
    "freePlaces" smallint
);


ALTER TABLE public.normal_plan OWNER TO postgres;

--
-- Name: nowplans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nowplans (
    "nowPlanId" integer NOT NULL,
    "startFrom" character varying(15),
    "goTo" character varying(15),
    "when" time without time zone,
    "airplaneId" integer,
    station1 integer,
    station2 integer,
    kind character(1),
    "travelTime" integer
);


ALTER TABLE public.nowplans OWNER TO postgres;

--
-- Name: nowplans_nowPlanId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."nowplans_nowPlanId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."nowplans_nowPlanId_seq" OWNER TO postgres;

--
-- Name: nowplans_nowPlanId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."nowplans_nowPlanId_seq" OWNED BY public.nowplans."nowPlanId";


--
-- Name: passengers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passengers (
    "passengerId" integer NOT NULL,
    ticket integer
);


ALTER TABLE public.passengers OWNER TO postgres;

--
-- Name: passport_controller; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passport_controller (
    "controllerId" integer NOT NULL,
    gate integer
);


ALTER TABLE public.passport_controller OWNER TO postgres;

--
-- Name: person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person (
    "personId" integer NOT NULL,
    name character varying(25),
    surname character varying(25),
    "addressId" integer,
    passenger boolean,
    employee boolean,
    "Tel no" integer
);


ALTER TABLE public.person OWNER TO postgres;

--
-- Name: person_name_update; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.person_name_update (
    "personId" integer NOT NULL,
    "oldName" character varying(50),
    "newName" character varying(50)
);


ALTER TABLE public.person_name_update OWNER TO postgres;

--
-- Name: person_personId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."person_personId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."person_personId_seq" OWNER TO postgres;

--
-- Name: person_personId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."person_personId_seq" OWNED BY public.person."personId";


--
-- Name: pilot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pilot (
    "pilotId" integer NOT NULL,
    "airplaneId" integer
);


ALTER TABLE public.pilot OWNER TO postgres;

--
-- Name: stations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stations (
    "stationId" integer NOT NULL,
    "stationName" character varying(15)
);


ALTER TABLE public.stations OWNER TO postgres;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket (
    "ticketId" integer NOT NULL,
    "airplaneId" integer,
    baggage integer,
    date date,
    "passengerId" integer,
    side smallint,
    "gateId" integer,
    "planId" integer
);


ALTER TABLE public.ticket OWNER TO postgres;

--
-- Name: ticket_canceletion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_canceletion (
    "ticketId" integer NOT NULL,
    passenger character varying(15),
    "passengerId" integer
);


ALTER TABLE public.ticket_canceletion OWNER TO postgres;

--
-- Name: ticket_ticketId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ticket_ticketId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ticket_ticketId_seq" OWNER TO postgres;

--
-- Name: ticket_ticketId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ticket_ticketId_seq" OWNED BY public.ticket."ticketId";


--
-- Name: vip; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vip (
    "vipId" integer NOT NULL,
    balance money,
    "maxBaggageNo" smallint DEFAULT 3,
    "maxWeight" double precision DEFAULT 40,
    "freePlaces" smallint DEFAULT 20
);


ALTER TABLE public.vip OWNER TO postgres;

--
-- Name: weather; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weather (
    "weatherId" integer NOT NULL,
    date date DEFAULT '2024-12-21'::date,
    weather character varying(15),
    degree integer
);


ALTER TABLE public.weather OWNER TO postgres;

--
-- Name: weather_weatherId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."weather_weatherId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."weather_weatherId_seq" OWNER TO postgres;

--
-- Name: weather_weatherId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."weather_weatherId_seq" OWNED BY public.weather."weatherId";


--
-- Name: adress adressId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adress ALTER COLUMN "adressId" SET DEFAULT nextval('public."adress_adressId_seq"'::regclass);


--
-- Name: airplane airplaneId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airplane ALTER COLUMN "airplaneId" SET DEFAULT nextval('public."airplane_airplaneId_seq"'::regclass);


--
-- Name: booking bookingId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking ALTER COLUMN "bookingId" SET DEFAULT nextval('public."booking_bookingId_seq"'::regclass);


--
-- Name: managers_update manUpdate; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers_update ALTER COLUMN "manUpdate" SET DEFAULT nextval('public."managers_update_manUpdate_seq"'::regclass);


--
-- Name: nowplans nowPlanId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nowplans ALTER COLUMN "nowPlanId" SET DEFAULT nextval('public."nowplans_nowPlanId_seq"'::regclass);


--
-- Name: person personId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person ALTER COLUMN "personId" SET DEFAULT nextval('public."person_personId_seq"'::regclass);


--
-- Name: ticket ticketId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket ALTER COLUMN "ticketId" SET DEFAULT nextval('public."ticket_ticketId_seq"'::regclass);


--
-- Name: weather weatherId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weather ALTER COLUMN "weatherId" SET DEFAULT nextval('public."weather_weatherId_seq"'::regclass);


--
-- Data for Name: adress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adress ("adressId", "countryId", "cityId") FROM stdin;
\.
COPY public.adress ("adressId", "countryId", "cityId") FROM '$$PATH$$/5052.dat';

--
-- Data for Name: airplane; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.airplane ("airplaneId", "pilotId", passengers, gate) FROM stdin;
\.
COPY public.airplane ("airplaneId", "pilotId", passengers, gate) FROM '$$PATH$$/5038.dat';

--
-- Data for Name: baggage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.baggage ("baggageId", "passengerId", weight) FROM stdin;
\.
COPY public.baggage ("baggageId", "passengerId", weight) FROM '$$PATH$$/5036.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.booking ("bookingId", "planId", "gateId", "ticketId") FROM stdin;
\.
COPY public.booking ("bookingId", "planId", "gateId", "ticketId") FROM '$$PATH$$/5040.dat';

--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city ("cityId", "cityName") FROM stdin;
\.
COPY public.city ("cityId", "cityName") FROM '$$PATH$$/5042.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.country ("countryId", "countryName") FROM stdin;
\.
COPY public.country ("countryId", "countryName") FROM '$$PATH$$/5041.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee ("employeeId", "startedData", salary, kind) FROM stdin;
\.
COPY public.employee ("employeeId", "startedData", salary, kind) FROM '$$PATH$$/5050.dat';

--
-- Data for Name: gates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gates ("gatesId", "gateName") FROM stdin;
\.
COPY public.gates ("gatesId", "gateName") FROM '$$PATH$$/5033.dat';

--
-- Data for Name: manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manager ("managerId") FROM stdin;
\.
COPY public.manager ("managerId") FROM '$$PATH$$/5031.dat';

--
-- Data for Name: managers_update; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.managers_update ("manUpdate", "lastManagerId", "lastManagerName", "newManagerId", "newManagerName") FROM stdin;
\.
COPY public.managers_update ("manUpdate", "lastManagerId", "lastManagerName", "newManagerId", "newManagerName") FROM '$$PATH$$/5055.dat';

--
-- Data for Name: normal_plan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.normal_plan ("normalPlanId", balance, "maxBaggageNo", "maxWeight", "freePlaces") FROM stdin;
\.
COPY public.normal_plan ("normalPlanId", balance, "maxBaggageNo", "maxWeight", "freePlaces") FROM '$$PATH$$/5047.dat';

--
-- Data for Name: nowplans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nowplans ("nowPlanId", "startFrom", "goTo", "when", "airplaneId", station1, station2, kind, "travelTime") FROM stdin;
\.
COPY public.nowplans ("nowPlanId", "startFrom", "goTo", "when", "airplaneId", station1, station2, kind, "travelTime") FROM '$$PATH$$/5045.dat';

--
-- Data for Name: passengers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passengers ("passengerId", ticket) FROM stdin;
\.
COPY public.passengers ("passengerId", ticket) FROM '$$PATH$$/5029.dat';

--
-- Data for Name: passport_controller; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passport_controller ("controllerId", gate) FROM stdin;
\.
COPY public.passport_controller ("controllerId", gate) FROM '$$PATH$$/5030.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.person ("personId", name, surname, "addressId", passenger, employee, "Tel no") FROM stdin;
\.
COPY public.person ("personId", name, surname, "addressId", passenger, employee, "Tel no") FROM '$$PATH$$/5028.dat';

--
-- Data for Name: person_name_update; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.person_name_update ("personId", "oldName", "newName") FROM stdin;
\.
COPY public.person_name_update ("personId", "oldName", "newName") FROM '$$PATH$$/5056.dat';

--
-- Data for Name: pilot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pilot ("pilotId", "airplaneId") FROM stdin;
\.
COPY public.pilot ("pilotId", "airplaneId") FROM '$$PATH$$/5032.dat';

--
-- Data for Name: stations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stations ("stationId", "stationName") FROM stdin;
\.
COPY public.stations ("stationId", "stationName") FROM '$$PATH$$/5043.dat';

--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket ("ticketId", "airplaneId", baggage, date, "passengerId", side, "gateId", "planId") FROM stdin;
\.
COPY public.ticket ("ticketId", "airplaneId", baggage, date, "passengerId", side, "gateId", "planId") FROM '$$PATH$$/5035.dat';

--
-- Data for Name: ticket_canceletion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_canceletion ("ticketId", passenger, "passengerId") FROM stdin;
\.
COPY public.ticket_canceletion ("ticketId", passenger, "passengerId") FROM '$$PATH$$/5053.dat';

--
-- Data for Name: vip; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vip ("vipId", balance, "maxBaggageNo", "maxWeight", "freePlaces") FROM stdin;
\.
COPY public.vip ("vipId", balance, "maxBaggageNo", "maxWeight", "freePlaces") FROM '$$PATH$$/5046.dat';

--
-- Data for Name: weather; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weather ("weatherId", date, weather, degree) FROM stdin;
\.
COPY public.weather ("weatherId", date, weather, degree) FROM '$$PATH$$/5049.dat';

--
-- Name: adress_adressId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."adress_adressId_seq"', 1, false);


--
-- Name: airplane_airplaneId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."airplane_airplaneId_seq"', 1, false);


--
-- Name: booking_bookingId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."booking_bookingId_seq"', 4, true);


--
-- Name: managers_update_manUpdate_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."managers_update_manUpdate_seq"', 2, true);


--
-- Name: nowplans_nowPlanId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."nowplans_nowPlanId_seq"', 2, true);


--
-- Name: person_personId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."person_personId_seq"', 54, true);


--
-- Name: ticket_ticketId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ticket_ticketId_seq"', 13, true);


--
-- Name: weather_weatherId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."weather_weatherId_seq"', 1, false);


--
-- Name: adress adressPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adress
    ADD CONSTRAINT "adressPK" PRIMARY KEY ("adressId");


--
-- Name: airplane airplanePK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airplane
    ADD CONSTRAINT "airplanePK" PRIMARY KEY ("airplaneId");


--
-- Name: baggage baggagePK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baggage
    ADD CONSTRAINT "baggagePK" PRIMARY KEY ("baggageId");


--
-- Name: booking bookingPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "bookingPK" PRIMARY KEY ("bookingId");


--
-- Name: city cityPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city
    ADD CONSTRAINT "cityPK" PRIMARY KEY ("cityId");


--
-- Name: country countryPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT "countryPK" PRIMARY KEY ("countryId");


--
-- Name: employee empPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT "empPK" PRIMARY KEY ("employeeId");


--
-- Name: gates gatesPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gates
    ADD CONSTRAINT "gatesPK" PRIMARY KEY ("gatesId");


--
-- Name: manager managerPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT "managerPK" PRIMARY KEY ("managerId");


--
-- Name: managers_update managers_update_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers_update
    ADD CONSTRAINT managers_update_pkey PRIMARY KEY ("manUpdate");


--
-- Name: normal_plan normalPlanPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.normal_plan
    ADD CONSTRAINT "normalPlanPK" PRIMARY KEY ("normalPlanId");


--
-- Name: nowplans nowPlanPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nowplans
    ADD CONSTRAINT "nowPlanPK" PRIMARY KEY ("nowPlanId");


--
-- Name: passport_controller passControllerPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passport_controller
    ADD CONSTRAINT "passControllerPK" PRIMARY KEY ("controllerId");


--
-- Name: passengers passengersPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT "passengersPK" PRIMARY KEY ("passengerId");


--
-- Name: person personPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT "personPK" PRIMARY KEY ("personId");


--
-- Name: person_name_update person_name_update_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person_name_update
    ADD CONSTRAINT person_name_update_pkey PRIMARY KEY ("personId");


--
-- Name: pilot pilotPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pilot
    ADD CONSTRAINT "pilotPK" PRIMARY KEY ("pilotId");


--
-- Name: stations stationsPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT "stationsPK" PRIMARY KEY ("stationId");


--
-- Name: ticket ticketPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT "ticketPK" PRIMARY KEY ("ticketId");


--
-- Name: ticket_canceletion ticket_canceletion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_canceletion
    ADD CONSTRAINT ticket_canceletion_pkey PRIMARY KEY ("ticketId");


--
-- Name: vip vipPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vip
    ADD CONSTRAINT "vipPK" PRIMARY KEY ("vipId");


--
-- Name: weather weatherPK; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weather
    ADD CONSTRAINT "weatherPK" PRIMARY KEY ("weatherId");


--
-- Name: ticket booking_after_add_ticket; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER booking_after_add_ticket AFTER INSERT ON public.ticket FOR EACH ROW EXECUTE FUNCTION public.make_booking();


--
-- Name: manager manager_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER manager_update AFTER INSERT OR UPDATE ON public.manager FOR EACH ROW EXECUTE FUNCTION public.manager_update_trigger();


--
-- Name: person person_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER person_update AFTER UPDATE ON public.person FOR EACH ROW EXECUTE FUNCTION public.person_update_trigger();


--
-- Name: ticket ticket_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER ticket_delete AFTER DELETE ON public.ticket FOR EACH ROW EXECUTE FUNCTION public.ticket_delete_trigger();


--
-- Name: adress adressCityFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adress
    ADD CONSTRAINT "adressCityFK" FOREIGN KEY ("cityId") REFERENCES public.city("cityId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: adress adressCountryFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adress
    ADD CONSTRAINT "adressCountryFK" FOREIGN KEY ("countryId") REFERENCES public.country("countryId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: airplane airplaneGateKF; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.airplane
    ADD CONSTRAINT "airplaneGateKF" FOREIGN KEY (gate) REFERENCES public.gates("gatesId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: baggage baggagePassengerFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baggage
    ADD CONSTRAINT "baggagePassengerFK" FOREIGN KEY ("passengerId") REFERENCES public.passengers("passengerId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking bookingGateFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "bookingGateFK" FOREIGN KEY ("gateId") REFERENCES public.gates("gatesId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking bookingPlanFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "bookingPlanFK" FOREIGN KEY ("planId") REFERENCES public.nowplans("nowPlanId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking bookingTicketIdFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.booking
    ADD CONSTRAINT "bookingTicketIdFK" FOREIGN KEY ("ticketId") REFERENCES public.ticket("ticketId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employee employeePersonInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT "employeePersonInheritanceFK" FOREIGN KEY ("employeeId") REFERENCES public.person("personId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: manager managerEmployeeInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT "managerEmployeeInheritanceFK" FOREIGN KEY ("managerId") REFERENCES public.employee("employeeId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: normal_plan normal_planNowplansInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.normal_plan
    ADD CONSTRAINT "normal_planNowplansInheritanceFK" FOREIGN KEY ("normalPlanId") REFERENCES public.nowplans("nowPlanId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nowplans nowplansAirplaneFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nowplans
    ADD CONSTRAINT "nowplansAirplaneFK" FOREIGN KEY ("airplaneId") REFERENCES public.airplane("airplaneId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nowplans nowplansStation1FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nowplans
    ADD CONSTRAINT "nowplansStation1FK" FOREIGN KEY (station1) REFERENCES public.stations("stationId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: nowplans nowplansStation2FK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nowplans
    ADD CONSTRAINT "nowplansStation2FK" FOREIGN KEY (station2) REFERENCES public.stations("stationId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: passengers passengerPersonInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT "passengerPersonInheritanceFK" FOREIGN KEY ("passengerId") REFERENCES public.person("personId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: passengers passengersTicketFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT "passengersTicketFK" FOREIGN KEY (ticket) REFERENCES public.ticket("ticketId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: passport_controller passport_controllerEmployeeInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passport_controller
    ADD CONSTRAINT "passport_controllerEmployeeInheritanceFK" FOREIGN KEY ("controllerId") REFERENCES public.employee("employeeId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: passport_controller passport_controllerGatesFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passport_controller
    ADD CONSTRAINT "passport_controllerGatesFK" FOREIGN KEY (gate) REFERENCES public.gates("gatesId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: person personAddressFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT "personAddressFK" FOREIGN KEY ("addressId") REFERENCES public.adress("adressId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pilot pilotAirplaneFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pilot
    ADD CONSTRAINT "pilotAirplaneFK" FOREIGN KEY ("airplaneId") REFERENCES public.airplane("airplaneId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pilot pilotEmployeeInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pilot
    ADD CONSTRAINT "pilotEmployeeInheritanceFK" FOREIGN KEY ("pilotId") REFERENCES public.employee("employeeId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ticket ticketAirplaneFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT "ticketAirplaneFK" FOREIGN KEY ("airplaneId") REFERENCES public.airplane("airplaneId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ticket ticketBaggageFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT "ticketBaggageFK" FOREIGN KEY (baggage) REFERENCES public.baggage("baggageId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ticket ticketGateFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT "ticketGateFK" FOREIGN KEY ("gateId") REFERENCES public.gates("gatesId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ticket ticketPassengerFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT "ticketPassengerFK" FOREIGN KEY ("passengerId") REFERENCES public.passengers("passengerId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ticket ticketPlanFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT "ticketPlanFK" FOREIGN KEY ("planId") REFERENCES public.nowplans("nowPlanId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vip vipNowplansInheritanceFK; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vip
    ADD CONSTRAINT "vipNowplansInheritanceFK" FOREIGN KEY ("vipId") REFERENCES public.nowplans("nowPlanId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

